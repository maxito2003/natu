package com.example.interfazinicio

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.interfazinicio.ui.theme.InterfazInicioTheme
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import com.example.interfazinicio.api.ApiService
import com.example.interfazinicio.api.ResponseAPI
import com.example.interfazinicio.api.RetrofitClient

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            InterfazInicioTheme {
                var pantalla by remember { mutableStateOf("login") }

                when (pantalla) {
                    "login" -> PantallaLogin(
                        onLoginExitoso = { pantalla = "home" },
                        onIrRegistro = { pantalla = "registro" }
                    )
                    "registro" -> PantallaRegistro(onRegistroExitoso = { pantalla = "login" })
                    "home" -> PantallaInicio(
                        onIrProductos = { pantalla = "productos" },
                        onIrPlantas = { pantalla = "plantas" },
                        onCerrarSesion = { pantalla = "login" }
                    )
                    "productos" -> PantallaProductos(onVolver = { pantalla = "home" })
                    "plantas" -> PantallaPlantas(onVolver = { pantalla = "home" })
                }
            }
        }
    }
}

@Composable
fun PantallaLogin(onLoginExitoso: () -> Unit, onIrRegistro: () -> Unit) {
    var usuario by remember { mutableStateOf("") }
    var contrasena by remember { mutableStateOf("") }
    var visible by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFCDECCF))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Natu", fontSize = 40.sp, color = Color(0xFF1B5E20))

        Spacer(Modifier.height(24.dp))

        OutlinedTextField(
            value = usuario,
            onValueChange = { usuario = it },
            label = { Text("Usuario") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = contrasena,
            onValueChange = { contrasena = it },
            label = { Text("Contraseña") },
            visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                IconButton(onClick = { visible = !visible }) {
                    Icon(
                        imageVector = if (visible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                        contentDescription = null
                    )
                }
            },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(24.dp))

        Button(
            onClick = {
                RetrofitClient.instance.login(usuario, contrasena)
                    .enqueue(object : Callback<ResponseAPI> {
                        override fun onResponse(
                            call: Call<ResponseAPI>,
                            response: Response<ResponseAPI>
                        ) {
                            val body = response.body()
                            if (body?.status == "ok") {
                                Toast.makeText(context, "Login exitoso", Toast.LENGTH_SHORT).show()
                                onLoginExitoso()
                            } else {
                                Toast.makeText(context, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show()
                            }
                        }

                        override fun onFailure(call: Call<ResponseAPI>, t: Throwable) {
                            Toast.makeText(context, "Error de conexión", Toast.LENGTH_SHORT).show()
                        }
                    })
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Enviar")
        }

        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onIrRegistro, modifier = Modifier.fillMaxWidth()) {
            Text("Registrarse")
        }
    }
}

@Composable
fun PantallaRegistro(onRegistroExitoso: () -> Unit) {
    val context = LocalContext.current

    var nombre by remember { mutableStateOf("") }
    var correo by remember { mutableStateOf("") }
    var usuario by remember { mutableStateOf("") }
    var contrasena by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFCDECCF))
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Registro", fontSize = 30.sp, color = Color(0xFF1B5E20))
        Spacer(Modifier.height(20.dp))

        OutlinedTextField(value = nombre, onValueChange = { nombre = it }, label = { Text("Nombre") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = correo, onValueChange = { correo = it }, label = { Text("Correo electrónico") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = usuario, onValueChange = { usuario = it }, label = { Text("Usuario") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = contrasena, onValueChange = { contrasena = it }, label = { Text("Contraseña") }, modifier = Modifier.fillMaxWidth())

        Spacer(Modifier.height(24.dp))

        Button(
            onClick = {
                RetrofitClient.instance.registro(
                    usuario, contrasena, nombre,
                    "", "", correo, "18"
                ).enqueue(object : Callback<ResponseAPI> {
                    override fun onResponse(
                        call: Call<ResponseAPI>,
                        response: Response<ResponseAPI>
                    ) {
                        val body = response.body()
                        if (body?.status == "ok") {
                            Toast.makeText(context, "Registro exitoso", Toast.LENGTH_SHORT).show()
                            onRegistroExitoso()
                        } else {
                            Toast.makeText(context, "Error al registrar", Toast.LENGTH_SHORT).show()
                        }
                    }

                    override fun onFailure(call: Call<ResponseAPI>, t: Throwable) {
                        Toast.makeText(context, "Error de conexión", Toast.LENGTH_SHORT).show()
                    }
                })
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Registrar")
        }

        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onRegistroExitoso, modifier = Modifier.fillMaxWidth()) {
            Text("Volver al inicio de sesión")
        }
    }
}

@Composable
fun PantallaInicio(onIrProductos: () -> Unit, onIrPlantas: () -> Unit, onCerrarSesion: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFCDECCF))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Natu", fontSize = 40.sp, color = Color(0xFF1B5E20))
        Spacer(Modifier.height(32.dp))

        Button(onClick = onIrProductos, modifier = Modifier.fillMaxWidth()) {
            Text("Productos")
        }
        Spacer(Modifier.height(16.dp))

        Button(onClick = onIrPlantas, modifier = Modifier.fillMaxWidth()) {
            Text("Plantas")
        }
        Spacer(Modifier.height(16.dp))

        OutlinedButton(onClick = onCerrarSesion, modifier = Modifier.fillMaxWidth()) {
            Text("Cerrar sesión")
        }
    }
}

@Composable
fun PantallaProductos(onVolver: () -> Unit) {
    val productos = listOf(
        Producto("Cepillo de Bambú", "Cepillo dental ecológico.", R.drawable.cepillo),
        Producto("Bolsa Reutilizable", "Bolsa de tela ecológica.", R.drawable.bolsa),
        Producto("Jabón Natural", "Jabón orgánico sin químicos.", R.drawable.jabon),
        Producto("Popote Metálico", "Popote ecológico reutilizable.", R.drawable.popote)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFCDECCF))
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Productos ecológicos", fontSize = 28.sp, color = Color(0xFF1B5E20))
        Spacer(Modifier.height(16.dp))

        productos.forEach {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Image(
                        painter = painterResource(id = it.imagen),
                        contentDescription = it.nombre,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        contentScale = ContentScale.Crop
                    )
                    Text(it.nombre, fontSize = 20.sp, color = Color(0xFF1B5E20))
                    Text(it.descripcion)
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onVolver, modifier = Modifier.fillMaxWidth()) {
            Text("Volver")
        }
    }
}

@Composable
fun PantallaPlantas(onVolver: () -> Unit) {
    val plantas = listOf(
        Planta("Aloe Vera", "México", "Ayuda a curar quemaduras.", R.drawable.aloe),
        Planta("Lavanda", "Europa", "Aroma relajante.", R.drawable.lavanda),
        Planta("Menta", "Asia", "Refresca y ayuda a digestión.", R.drawable.menta),
        Planta("Eucalipto", "Asia", "Ayuda a respiración.", R.drawable.eucalipto)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFCDECCF))
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Plantas medicinales", fontSize = 28.sp, color = Color(0xFF1B5E20))
        Spacer(Modifier.height(16.dp))

        plantas.forEach {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Image(
                        painter = painterResource(id = it.imagen),
                        contentDescription = it.nombre,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        contentScale = ContentScale.Crop
                    )
                    Text(it.nombre, fontSize = 20.sp, color = Color(0xFF1B5E20))
                    Text("Origen: ${it.origen}")
                    Text("Uso: ${it.uso}")
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onVolver, modifier = Modifier.fillMaxWidth()) {
            Text("Volver")
        }
    }
}

data class Producto(val nombre: String, val descripcion: String, val imagen: Int)
data class Planta(val nombre: String, val origen: String, val uso: String, val imagen: Int)
