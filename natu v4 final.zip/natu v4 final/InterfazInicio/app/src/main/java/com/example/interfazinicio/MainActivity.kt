package com.example.interfazinicio

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.interfazinicio.api.ApiService
import com.example.interfazinicio.api.ResponseAPI
import com.example.interfazinicio.api.RetrofitClient
import com.example.interfazinicio.ui.theme.InterfazInicioTheme
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.graphics.Brush
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            InterfazInicioTheme {
                var pantalla by remember { mutableStateOf("splash") }
                var drawerOpen by remember { mutableStateOf(false) }
                var plantasCategoriaSeleccionada by remember { mutableStateOf("") }
                when (pantalla) {
                    "splash" -> PantallaSplash(onFinish = { pantalla = "login" })
                    "login" -> PantallaLogin(onLogin = { pantalla = "home" }, onIrRegistro = { pantalla = "registro" })
                    "registro" -> PantallaRegistro(
                        onRegistrar = {},
                        onVolverLogin = { pantalla = "login" }
                    )
                    "home" -> PantallaInicio(
                        onIrPlantas = { pantalla = "seleccion_categorias" },
                        onIrProductos = { pantalla = "productos" },
                        onIrVentas = { pantalla = "ventas" }
                    )
                    "seleccion_categorias" -> PantallaSeleccionCategorias(
                        onSeleccion = { cat ->
                            plantasCategoriaSeleccionada = cat
                            pantalla = "plantas"
                        },
                        onVolver = { pantalla = "home" }
                    )
                    "plantas" -> PantallaPlantasPorCategoria(
                        categoria = plantasCategoriaSeleccionada,
                        onVolver = { pantalla = "home" },
                        onVerDetalle = { nombre -> pantalla = "planta_detalle|$plantasCategoriaSeleccionada|$nombre" }
                    )
                    else -> {
                        if (pantalla.startsWith("planta_detalle|")) {
                            val parts = pantalla.split("|")
                            val cat = parts[1]
                            val nombre = parts[2]
                            PantallaDetallePlanta(categoria = cat, nombre = nombre, onVolver = { pantalla = "plantas" })
                        } else if (pantalla.startsWith("producto_detalle|")) {
                            val nombre = pantalla.split("|")[1]
                            PantallaDetalleProducto(nombre = nombre, onVolver = { pantalla = "productos" })
                        } else {
                            when (pantalla) {
                                "productos" -> PantallaProductosSinNav(onVerDetalle = { nombre -> pantalla = "producto_detalle|$nombre" }, onVolver = { pantalla = "home" })
                                "ventas" -> PantallaVentas(onVolver = { pantalla = "home" })
                                else -> Box(modifier = Modifier.fillMaxSize()) { Text("Pantalla desconocida") }
                            }
                        }
                    }
                }
            }
        }
    }
}
data class PlantaInfo(
    val nombre: String,
    val descripcion: String,
    val riego: String,
    val imagen: Int
)
@Composable
fun PantallaSplash(onFinish: () -> Unit) {
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(2000)
        onFinish()
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.pantallainicio),
            contentDescription = "Splash",
            modifier = Modifier.size(1100.dp)
        )
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaLogin(
    onLogin: () -> Unit,
    onIrRegistro: () -> Unit
) {
    val context = LocalContext.current
    var usuario by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var mostrarPassword by remember { mutableStateOf(false) }
    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.fondoir),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(60.dp))
            Text(
                text = "Iniciar Sesión",
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(30.dp))
            OutlinedTextField(
                value = usuario,
                onValueChange = { usuario = it },
                label = { Text("Usuario") },
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.White,
                    unfocusedIndicatorColor = Color.White,
                    cursorColor = Color.White,
                    focusedLabelColor = Color.White,
                    unfocusedLabelColor = Color.White,
                    disabledTextColor = Color.White,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Contraseña") },
                modifier = Modifier.fillMaxWidth(),
                visualTransformation = if (mostrarPassword) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { mostrarPassword = !mostrarPassword }) {
                        Icon(
                            imageVector = if (mostrarPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Ver contraseña",
                            tint = Color.White
                        )
                    }
                },
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.White,
                    unfocusedIndicatorColor = Color.White,
                    cursorColor = Color.White,
                    focusedLabelColor = Color.White,
                    unfocusedLabelColor = Color.White,
                    disabledTextColor = Color.White,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
            Spacer(modifier = Modifier.height(30.dp))
            Button(
                onClick = {
                    if (usuario.isBlank() || password.isBlank()) {
                        Toast.makeText(context, "Completa todos los campos", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    RetrofitClient.instance.login(usuario, password)
                        .enqueue(object : Callback<ResponseAPI> {
                            override fun onResponse(
                                call: Call<ResponseAPI>,
                                response: Response<ResponseAPI>
                            ) {
                                val body = response.body()
                                if (body?.status == "ok") {
                                    Toast.makeText(context, "Bienvenido", Toast.LENGTH_SHORT).show()
                                    onLogin()
                                } else {
                                    Toast.makeText(context, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show()
                                }
                            }

                            override fun onFailure(call: Call<ResponseAPI>, t: Throwable) {
                                Toast.makeText(context, "Error de conexión", Toast.LENGTH_SHORT).show()
                            }
                        })
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(55.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50))
            ) {
                Text("Ingresar", fontSize = 18.sp, color = Color.White)
            }
            Spacer(modifier = Modifier.height(14.dp))
            OutlinedButton(
                onClick = { onIrRegistro() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(55.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
            ) {
                Text("Crear cuenta", fontSize = 16.sp)
            }
        }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaRegistro(
    onRegistrar: () -> Unit,
    onVolverLogin: () -> Unit
) {
    val context = LocalContext.current
    var usuario by remember { mutableStateOf("") }
    var contrasena by remember { mutableStateOf("") }
    var nombre by remember { mutableStateOf("") }
    var correo by remember { mutableStateOf("") }
    var mostrarPassword by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.fondoir),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(40.dp))
            Text(
                text = "Crear Cuenta",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(20.dp))
            OutlinedTextField(
                value = usuario,
                onValueChange = { usuario = it },
                label = { Text("Usuario") },
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.White,
                    unfocusedIndicatorColor = Color.White,
                    cursorColor = Color.White,
                    focusedLabelColor = Color.White,
                    unfocusedLabelColor = Color.White,
                    disabledTextColor = Color.White,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(
                value = nombre,
                onValueChange = { nombre = it },
                label = { Text("Nombre completo") },
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.White,
                    unfocusedIndicatorColor = Color.White,
                    cursorColor = Color.White,
                    focusedLabelColor = Color.White,
                    unfocusedLabelColor = Color.White,
                    disabledTextColor = Color.White,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(
                value = correo,
                onValueChange = { correo = it },
                label = { Text("Correo electrónico") },
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.White,
                    unfocusedIndicatorColor = Color.White,
                    cursorColor = Color.White,
                    focusedLabelColor = Color.White,
                    unfocusedLabelColor = Color.White,
                    disabledTextColor = Color.White,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(
                value = contrasena,
                onValueChange = { contrasena = it },
                label = { Text("Contraseña") },
                modifier = Modifier.fillMaxWidth(),
                visualTransformation = if (mostrarPassword) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { mostrarPassword = !mostrarPassword }) {
                        Icon(
                            imageVector = if (mostrarPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Ver contraseña",
                            tint = Color.White
                        )
                    }
                },
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color.White,
                    unfocusedIndicatorColor = Color.White,
                    cursorColor = Color.White,
                    focusedLabelColor = Color.White,
                    unfocusedLabelColor = Color.White,
                    disabledTextColor = Color.White,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
            Spacer(modifier = Modifier.height(30.dp))
            Button(
                onClick = {
                    RetrofitClient.instance.registro(
                        usuario,
                        contrasena,
                        nombre,
                        "",
                        "",
                        correo,
                        "18"
                    ).enqueue(object : Callback<ResponseAPI> {
                        override fun onResponse(
                            call: Call<ResponseAPI>,
                            response: Response<ResponseAPI>
                        ) {
                            val body = response.body()
                            if (body?.status == "ok") {
                                Toast.makeText(context, "Registro exitoso", Toast.LENGTH_SHORT).show()
                                onRegistrar()
                            } else {
                                Toast.makeText(context, "Error al registrar", Toast.LENGTH_SHORT).show()
                            }
                        }
                        override fun onFailure(call: Call<ResponseAPI>, t: Throwable) {
                            Toast.makeText(context, "Error de conexión", Toast.LENGTH_SHORT).show()
                        }
                    })
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(55.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50))
            ) {
                Text("Registrar", fontSize = 18.sp, color = Color.White)
            }

            Spacer(modifier = Modifier.height(12.dp))
            OutlinedButton(
                onClick = { onVolverLogin() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(55.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = Color.White
                )
            ) {
                Text("Volver al inicio de sesión", fontSize = 16.sp)
            }
        }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaInicio(
    onIrPlantas: () -> Unit,
    onIrProductos: () -> Unit,
    onIrVentas: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.fondoir),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(50.dp))
            Image(
                painter = painterResource(id = R.drawable.logo_natu),
                contentDescription = "Logo",
                modifier = Modifier.size(160.dp)
            )
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "Sembrando conciencia,\ncosechando vida",
                textAlign = TextAlign.Center,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(40.dp))

            Button(
                onClick = onIrPlantas,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF7BBF6A)
                ),
                shape = RoundedCornerShape(30.dp)
            ) {
                Text("Plantas", fontSize = 18.sp, color = Color.White)
            }
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onIrProductos,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF2F5930)
                ),
                shape = RoundedCornerShape(30.dp)
            ) {
                Text("Productos", fontSize = 18.sp, color = Color.White)
            }
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onIrVentas,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF8D6E63)
                ),
                shape = RoundedCornerShape(30.dp)
            ) {
                Text("Ventas", fontSize = 18.sp, color = Color.White)
            }
        }
    }
}
@Composable
fun PantallaSeleccionCategorias(
    onSeleccion: (String) -> Unit,
    onVolver: () -> Unit
) {
    val cafe = Color(0xFF8D6E63)
    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.plantaobjetos),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 40.dp)
                .padding(top = 0.1.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            Spacer(modifier = Modifier.height(60.dp))
            Button(
                onClick = { onSeleccion("solar") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(55.dp),
                colors = ButtonDefaults.buttonColors(containerColor = cafe),
                shape = RoundedCornerShape(40.dp)
            ) {
                Text("Plantas sol", color = Color.White)
            }
            Button(
                onClick = { onSeleccion("sombra") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(55.dp),
                colors = ButtonDefaults.buttonColors(containerColor = cafe),
                shape = RoundedCornerShape(40.dp)
            ) {
                Text("Plantas sombra", color = Color.White)
            }
            Button(
                onClick = { onSeleccion("sol_y_sombra") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(55.dp),
                colors = ButtonDefaults.buttonColors(containerColor = cafe),
                shape = RoundedCornerShape(40.dp)
            ) {
                Text("Plantas sol y sombra", color = Color.White)
            }
            Button(
                onClick = { onSeleccion("medicinales") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(55.dp),
                colors = ButtonDefaults.buttonColors(containerColor = cafe),
                shape = RoundedCornerShape(40.dp)
            ) {
                Text("Plantas medicinales", color = Color.White)
            }
            OutlinedButton(
                onClick = onVolver,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(40.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = cafe)
            ) {
                Text("Volver")
            }
            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}
@Composable
fun PantallaPlantasPorCategoria(
    categoria: String,
    onVolver: () -> Unit,
    onVerDetalle: (String) -> Unit
) {
    val plantas = when (categoria) {
        "solar" -> plantsSolar()
        "sombra" -> plantsSombra()
        "sol_y_sombra" -> plantsSolYSombra()
        "medicinales" -> plantsMedicinales()
        else -> plantsSolar()
    }
    val plantasMostradas = plantas.take(5)
    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.cuadros_categoria),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(top = 60.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            plantasMostradas.getOrNull(0)?.let { planta ->
                Box(
                    modifier = Modifier
                        .size(240.dp, 170.dp)
                        .clickable { onVerDetalle(planta.nombre) },
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = planta.imagen),
                        contentDescription = planta.nombre,
                        modifier = Modifier
                            .size(170.dp)
                            .clip(RoundedCornerShape(25.dp)),
                        contentScale = ContentScale.Crop
                    )
                }
            }
            Spacer(Modifier.height(20.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                plantasMostradas.getOrNull(1)?.let { planta ->
                    CuadroPlanta(planta, onVerDetalle)
                }
                plantasMostradas.getOrNull(2)?.let { planta ->
                    CuadroPlanta(planta, onVerDetalle)
                }
            }
            Spacer(Modifier.height(20.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                plantasMostradas.getOrNull(3)?.let { planta ->
                    CuadroPlanta(planta, onVerDetalle)
                }
                plantasMostradas.getOrNull(4)?.let { planta ->
                    CuadroPlanta(planta, onVerDetalle)
                }
            }
            Spacer(Modifier.height(30.dp))
            Button(
                onClick = onVolver,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                modifier = Modifier
                    .fillMaxWidth(0.6f)
                    .height(55.dp),
                shape = RoundedCornerShape(25.dp)
            ) {
                Text("Volver", color = Color.White, fontSize = 18.sp)
            }
            Spacer(Modifier.height(40.dp))
        }
    }
}
@Composable
fun CuadroPlanta(
    planta: PlantaInfo,
    onClick: (String) -> Unit
) {
    Box(
        modifier = Modifier
            .size(150.dp, 170.dp)
            .clickable { onClick(planta.nombre) },
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = planta.imagen),
            contentDescription = planta.nombre,
            modifier = Modifier
                .size(120.dp)
                .clip(RoundedCornerShape(25.dp)),
            contentScale = ContentScale.Crop
        )
    }
}
@Composable
fun PantallaDetallePlanta(
    categoria: String,
    nombre: String,
    onVolver: () -> Unit
) {
    val planta = findPlantByName(nombre, categoria)
    Box(
        modifier = Modifier
            .fillMaxSize()
    ) {
        Image(
            painter = painterResource(id = R.drawable.fondoinfo),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(30.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(50.dp))
            Image(
                painter = painterResource(id = planta.imagen),
                contentDescription = planta.nombre,
                modifier = Modifier
                    .size(230.dp)
                    .clip(CircleShape),
                contentScale = ContentScale.Crop
            )

            Spacer(Modifier.height(25.dp))

            Text(
                text = planta.nombre,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF2E4F37)
            )
            Spacer(Modifier.height(10.dp))

            Text(
                text = planta.descripcion,
                fontSize = 18.sp,
                color = Color(0xFF2E4F37)
            )
            Spacer(Modifier.height(10.dp))

            Text(
                text = "Riego: ${planta.riego}",
                fontSize = 18.sp,
                color = Color(0xFF2E4F37)
            )
            Spacer(Modifier.height(40.dp))
            Button(
                onClick = onVolver,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(55.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF1B5E20) // verde oscuro
                ),
                shape = RoundedCornerShape(25.dp)
            ) {
                Text("Volver", color = Color.White, fontSize = 18.sp)
            }
        }
    }
}
@Composable
fun PantallaProductosSinNav(
    onVerDetalle: (String) -> Unit,
    onVolver: () -> Unit
) {
    val productos = sampleProductos()
    val productosMostrados = productos.take(4)
    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.cuadros_categoria2),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 80.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                productosMostrados.getOrNull(0)?.let {
                    CuadroProducto(it, onVerDetalle)
                }
                productosMostrados.getOrNull(1)?.let {
                    CuadroProducto(it, onVerDetalle)
                }
            }
            Spacer(Modifier.height(40.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                productosMostrados.getOrNull(2)?.let {
                    CuadroProducto(it, onVerDetalle)
                }
                productosMostrados.getOrNull(3)?.let {
                    CuadroProducto(it, onVerDetalle)
                }
            }
            Spacer(Modifier.height(60.dp))
            Button(
                onClick = onVolver,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                modifier = Modifier
                    .fillMaxWidth(0.6f)
                    .height(55.dp),
                shape = RoundedCornerShape(25.dp)
            ) {
                Text("Volver", color = Color.White, fontSize = 18.sp)
            }
            Spacer(Modifier.height(40.dp))
        }
    }
}
@Composable
fun CuadroProducto(
    producto: Producto,
    onClick: (String) -> Unit
) {
    Box(
        modifier = Modifier
            .size(150.dp, 170.dp)
            .clickable { onClick(producto.nombre) },
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = producto.imagen),
            contentDescription = producto.nombre,
            modifier = Modifier
                .size(120.dp)
                .clip(RoundedCornerShape(25.dp)),
            contentScale = ContentScale.Crop
        )
    }
}
@Composable
fun PantallaDetalleProducto(
    nombre: String,
    onVolver: () -> Unit
) {
    val producto = sampleProductos().firstOrNull { it.nombre == nombre } ?: sampleProductos().first()
    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.fondoinfo2),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 30.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(120.dp))
            Image(
                painter = painterResource(id = producto.imagen),
                contentDescription = producto.nombre,
                modifier = Modifier
                    .size(180.dp)
                    .clip(CircleShape),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.height(20.dp))
            Text(
                text = producto.nombre,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF2E4F37)
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text = producto.descripcion,
                fontSize = 18.sp,
                color = Color(0xFF2E4F37)
            )
            Spacer(Modifier.height(40.dp))
            Button(
                onClick = onVolver,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(55.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                shape = RoundedCornerShape(25.dp)
            ) {
                Text("Volver", color = Color.White, fontSize = 18.sp)
            }
            Spacer(Modifier.height(40.dp))
        }
    }
}
@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun PantallaVentas(onVolver: () -> Unit) {
    var tipoTarjeta by remember { mutableStateOf("credito") }
    var numero by remember { mutableStateOf("") }
    var nombre by remember { mutableStateOf("") }
    var expiracion by remember { mutableStateOf("") }
    var cvv by remember { mutableStateOf("") }
    var producto by remember { mutableStateOf("") }
    var cantidad by remember { mutableStateOf("") }
    val context = LocalContext.current
    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.fondoir),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Método de pago", fontSize = 28.sp, color = Color.White)
            Spacer(Modifier.height(20.dp))
            Text("Selecciona tipo de tarjeta", fontSize = 18.sp, color = Color.White)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = tipoTarjeta == "credito",
                    onClick = { tipoTarjeta = "credito" }
                )
                Text("Crédito", color = Color.White)
                Spacer(Modifier.width(20.dp))
                RadioButton(
                    selected = tipoTarjeta == "debito",
                    onClick = { tipoTarjeta = "debito" }
                )
                Text("Débito", color = Color.White)
            }
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(
                value = numero,
                onValueChange = { numero = it },
                label = { Text("Número de tarjeta", color = Color.White) },
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedLabelColor = Color.White,
                    unfocusedLabelColor = Color.White,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedIndicatorColor = Color.White,
                    unfocusedIndicatorColor = Color.White,
                    cursorColor = Color.White
                )
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = nombre,
                onValueChange = { nombre = it },
                label = { Text("Nombre del titular", color = Color.White) },
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedLabelColor = Color.White,
                    unfocusedLabelColor = Color.White,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedIndicatorColor = Color.White,
                    unfocusedIndicatorColor = Color.White,
                    cursorColor = Color.White
                )
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = expiracion,
                onValueChange = { expiracion = it },
                label = { Text("Fecha expiración (MM/AA)", color = Color.White) },
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedLabelColor = Color.White,
                    unfocusedLabelColor = Color.White,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedIndicatorColor = Color.White,
                    unfocusedIndicatorColor = Color.White,
                    cursorColor = Color.White
                )
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = cvv,
                onValueChange = { cvv = it },
                label = { Text("CVV", color = Color.White) },
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedLabelColor = Color.White,
                    unfocusedLabelColor = Color.White,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedIndicatorColor = Color.White,
                    unfocusedIndicatorColor = Color.White,
                    cursorColor = Color.White
                )
            )
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(
                value = producto,
                onValueChange = { producto = it },
                label = { Text("Producto", color = Color.White) },
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedLabelColor = Color.White,
                    unfocusedLabelColor = Color.White,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedIndicatorColor = Color.White,
                    unfocusedIndicatorColor = Color.White,
                    cursorColor = Color.White
                )
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = cantidad,
                onValueChange = { cantidad = it },
                label = { Text("Cantidad", color = Color.White) },
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedLabelColor = Color.White,
                    unfocusedLabelColor = Color.White,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedIndicatorColor = Color.White,
                    unfocusedIndicatorColor = Color.White,
                    cursorColor = Color.White
                )
            )
            Spacer(Modifier.height(25.dp))
            Button(
                onClick = {
                    RetrofitClient.instance.registrarVenta(
                        numero,
                        nombre,
                        expiracion,
                        cvv,
                        producto,
                        cantidad
                    ).enqueue(object : Callback<ResponseAPI> {
                        override fun onResponse(
                            call: Call<ResponseAPI>,
                            response: Response<ResponseAPI>
                        ) {
                            if (response.body()?.status == "ok") {
                                Toast.makeText(context, "Venta registrada", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Error al registrar", Toast.LENGTH_SHORT).show()
                            }
                        }

                        override fun onFailure(call: Call<ResponseAPI>, t: Throwable) {
                            Toast.makeText(context, "Error de conexión", Toast.LENGTH_SHORT).show()
                        }
                    })
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6D4C41))  // ✔ color cambiado
            ) {
                Text("Realizar compra", color = Color.White)
            }
            Spacer(Modifier.height(15.dp))

            OutlinedButton(
                onClick = onVolver,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Volver", color = Color.White)
            }
        }
    }
}
data class PlantsInfo(val nombre: String, val descripcion: String, val riego: String, val imagen: Int)
fun plantsSolar(): List<PlantaInfo> = listOf(
    PlantaInfo("Bugambilia", "Planta trepadora muy popular en climas cálidos. Produce brácteas de colores brillantes (rosa, morado, blanco, naranja). Crece rápido, decora muros y soporta bien el calor intenso.", "Cada 5–7 días", R.drawable.bugambilia),
    PlantaInfo("Hibisco (Rosa de Jamaica)", "Arbusto tropical con flores grandes y vistosas en colores rojos, amarillos o rosados. Atrae colibríes y se adapta bien al sol fuerte.", "Cada 3–4 días", R.drawable.hibisco),
    PlantaInfo("Margarita", "Planta resistente y fácil de cuidar, con flores clásicas blancas y amarillas. Ideal para jardines soleados y floraciones prolongadas.", "Cada 4–5 días", R.drawable.margarita),
    PlantaInfo("Tomillo", "Hierba aromática de hojas pequeñas y olor fuerte. Es una planta muy rústica que tolera sequía, ideal para cocina y jardinería mediterránea.", "Cada 7–10 días", R.drawable.tomillo),
    PlantaInfo("Yuca", "Arbusto de hojas largas y puntiagudas. Muy resistente al calor, sequía y suelos pobres. Da un toque desértico y elegante al jardín.", "Cada 10–12 días", R.drawable.yuca)
)
fun plantsSombra(): List<PlantaInfo> = listOf(
    PlantaInfo("Helecho Boston", "Planta frondosa con hojas largas que crean un aspecto fresco y elegante. Ideal para interiores húmedos o baños.", "Cada 3–4 días", R.drawable.helecho),
    PlantaInfo("Potus (Poto)", "Planta colgante de hojas verdes o variegadas. Crece rápido, purifica el aire y tolera poca luz. Perfecta para principiantes.", "Cada 5–7 días", R.drawable.potus),
    PlantaInfo("Calathea", "Conocida por sus hojas con patrones únicos (rayas, manchas o tonos morados). Es sensible al sol directo y prefiere ambientes frescos.", "Cada 3–5 días", R.drawable.calathea),
    PlantaInfo("Sansevieria (Lengua de suegra)", "Planta extremadamente resistente, con hojas verticales y duras. Sobrevive en poca luz y requiere muy poca agua.", "Cada 15–20 días", R.drawable.sansevieria),
    PlantaInfo("Lirio de la paz", "Planta elegante de hojas verdes oscuras que produce flores blancas. Purifica el aire y es ideal para interiores con sombra.", "Cada 4–6 días", R.drawable.liriodelapaz)
)
fun plantsSolYSombra(): List<PlantaInfo> = listOf(
    PlantaInfo("Menta", "Planta aromática fresca que se expande con facilidad. Ideal para infusiones, postres y repelente natural de insectos.", "Cada 2–3 días", R.drawable.menta),
    PlantaInfo("Albahaca", "Gran aroma y sabor; usada en cocina. Le gusta el sol suave, pero también puede vivir con sombra parcial.", "Cada 2–3 días", R.drawable.albahaca),
    PlantaInfo("Geranio", "Planta de flores muy coloridas que pueden ser rosadas, rojas, blancas o moradas. Muy usada en macetas y balcones.", "Cada 4–5 días", R.drawable.geranio),
    PlantaInfo("Planta Jade (Crassula ovata)", "Suculenta de hojas redondas y brillantes. Representa prosperidad y crece bien en interiores luminosos o sol suave.", "Cada 10–12 días", R.drawable.jade),
    PlantaInfo("Ficus Benjamina", "Árbol pequeño muy común en interiores. Tiene hojas delgadas y elegantes, crece hacia arriba y necesita luz filtrada.", "Cada 7 días", R.drawable.ficus)
)
fun plantsMedicinales(): List<PlantaInfo> = listOf(
    PlantaInfo("Salvia", "Planta aromática con hojas verdes y un aroma suave. Se utiliza para aliviar dolores de garganta, mejorar la digestión y reducir inflamación. También es conocida por sus propiedades antibacterianas y calmantes.", "Cada 4–6 días", R.drawable.salvia),
    PlantaInfo("Hierbabuena", "Similar a la menta pero más intensa en aroma. Se usa para cólicos, digestión y bebidas frescas. Crece muy rápido.", "Cada 2–3 días", R.drawable.hierbabuena),
    PlantaInfo("Eucalipto (pequeño)", "Árbol aromático que ayuda a despejar vías respiratorias. Cuando es pequeño puede vivir en maceta con buena luz.", "Cada 5–7 días", R.drawable.eucalipto),
    PlantaInfo("Toronjil / Melisa", "Planta con olor suave a limón, usada para ansiedad, insomnio y nervios. Muy noble y fácil de cuidar.", "Cada 2–3 días", R.drawable.melisa),
    PlantaInfo("Arnica", "Planta silvestre usada externamente para golpes, torceduras y dolor muscular. Sus flores son amarillas y muy llamativas.", "Cada 4–6 días", R.drawable.arnica)
)
fun findPlantByName(nombre: String, categoria: String): PlantaInfo {
    val list = when (categoria) {
        "solar" -> plantsSolar()
        "sombra" -> plantsSombra()
        "sol_y_sombra" -> plantsSolYSombra()
        "medicinales" -> plantsMedicinales()
        else -> plantsSolar()
    }
    return list.firstOrNull { it.nombre == nombre } ?: list.first()
}
data class Producto(val nombre: String, val descripcion: String, val imagen: Int)
fun sampleProductos(): List<Producto> = listOf(
    Producto("Cepillo de Bambú", "Cepillo dental hecho con bambú biodegradable. Costo $30 pesos mxn c/u", R.drawable.cepillob),
    Producto("Bolsa Reutilizable", "Bolsa de tela ecológica para compras. costo $10 pesos mxn c/u", R.drawable.bolsar),
    Producto("Jabón Natural", "Hecho con aceites esenciales y sin químicos. costo $50 pesos mxn c/u", R.drawable.jabonn),
    Producto("Popote Metálico", "Reutilizable, ideal para reducir el plástico. costo $10 pesos mxn c/u", R.drawable.popotem)
)