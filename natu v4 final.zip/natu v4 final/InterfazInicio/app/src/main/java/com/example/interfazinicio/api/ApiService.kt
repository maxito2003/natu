package com.example.interfazinicio.api   // ← tu paquete puede ser otro

import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

interface ApiService {

    @FormUrlEncoded
    @POST("login.php")
    fun login(
        @Field("usuario") usuario: String,
        @Field("contrasena") contrasena: String
    ): Call<ResponseAPI>


    @FormUrlEncoded
    @POST("registro.php")
    fun registro(
        @Field("usuario") usuario: String,
        @Field("contrasena") contrasena: String,
        @Field("nombre") nombre: String,
        @Field("apellido_m") apellido_m: String,
        @Field("apellido_p") apellido_p: String,
        @Field("correo_electronico") correo: String,
        @Field("edad") edad: String
    ): Call<ResponseAPI>

    @FormUrlEncoded
    @POST("registrarVenta.php")
    fun registrarVenta(
        @Field("numtar") numtar: String,
        @Field("nom") nom: String,
        @Field("fechaexp") fechaexp: String,
        @Field("cvv") cvv: String,
        @Field("producto") producto: String,
        @Field("cantidad") cantidad: String
    ): Call<ResponseAPI>
}
