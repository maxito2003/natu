package com.example.interfazinicio.api

data class ResponseAPI(
    val status: String,
    val message: String
)