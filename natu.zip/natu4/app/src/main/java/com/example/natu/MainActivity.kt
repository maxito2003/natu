package com.example.natu

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.natu.ui.theme.NatuTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NatuTheme {
                var pantalla by remember { mutableStateOf("login") }

                when (pantalla) {
                    "login" -> PantallaLogin(
                        onLogin = { pantalla = "home" },
                        onIrRegistro = { pantalla = "registro" }
                    )
                    "registro" -> PantallaRegistro(onVolver = { pantalla = "login" })
                    "home" -> PantallaInicio(
                        onIrProductos = { pantalla = "productos" },
                        onIrPlantas = { pantalla = "plantas" },
                        onCerrarSesion = { pantalla = "login" }
                    )
                    "productos" -> PantallaProductos(onVolver = { pantalla = "home" })
                    "plantas" -> PantallaPlantas(onVolver = { pantalla = "home" })
                }
            }
        }
    }
}

@Composable
fun PantallaLogin(onLogin: () -> Unit, onIrRegistro: () -> Unit) {
    var usuario by remember { mutableStateOf("") }
    var contrasena by remember { mutableStateOf("") }
    var visible by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFCDECCF))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Natu", fontSize = 40.sp, color = Color(0xFF1B5E20))

        Spacer(Modifier.height(24.dp))

        OutlinedTextField(
            value = usuario,
            onValueChange = { usuario = it },
            label = { Text("Usuario") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = contrasena,
            onValueChange = { contrasena = it },
            label = { Text("Contraseña") },
            visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                IconButton(onClick = { visible = !visible }) {
                    Icon(
                        imageVector = if (visible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                        contentDescription = null
                    )
                }
            },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onLogin, modifier = Modifier.fillMaxWidth()) {
            Text("Enviar")
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onIrRegistro, modifier = Modifier.fillMaxWidth()) {
            Text("Registrarse")
        }
    }
}
@Composable
fun PantallaRegistro(onVolver: () -> Unit) {
    var nombre by remember { mutableStateOf("") }
    var correo by remember { mutableStateOf("") }
    var usuario by remember { mutableStateOf("") }
    var contrasena by remember { mutableStateOf("") }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFCDECCF))
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Registro", fontSize = 30.sp, color = Color(0xFF1B5E20))
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(value = nombre, onValueChange = { nombre = it }, label = { Text("Nombre") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = correo, onValueChange = { correo = it }, label = { Text("Correo electrónico") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = usuario, onValueChange = { usuario = it }, label = { Text("Usuario") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = contrasena, onValueChange = { contrasena = it }, label = { Text("Contraseña") }, modifier = Modifier.fillMaxWidth())

        Spacer(Modifier.height(24.dp))
        Button(onClick = onVolver, modifier = Modifier.fillMaxWidth()) {
            Text("Registrar")
        }

        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onVolver, modifier = Modifier.fillMaxWidth()) {
            Text("Volver al inicio de sesión")
        }
    }
}

@Composable
fun PantallaInicio(onIrProductos: () -> Unit, onIrPlantas: () -> Unit, onCerrarSesion: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFCDECCF))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Natu", fontSize = 40.sp, color = Color(0xFF1B5E20))
        Spacer(Modifier.height(32.dp))
        Button(onClick = onIrProductos, modifier = Modifier.fillMaxWidth()) {
            Text("Productos")
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = onIrPlantas, modifier = Modifier.fillMaxWidth()) {
            Text("Plantas")
        }
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onClick = onCerrarSesion, modifier = Modifier.fillMaxWidth()) {
            Text("Cerrar sesión")
        }
    }
}

@Composable
fun PantallaProductos(onVolver: () -> Unit) {
    val productos = listOf(
        Producto("Cepillo de Bambú", "Cepillo dental hecho con bambú biodegradable.", R.drawable.cepillo),
        Producto("Bolsa Reutilizable", "Bolsa de tela ecológica para compras.", R.drawable.bolsa),
        Producto("Jabón Natural", "Hecho con aceites esenciales y sin químicos.", R.drawable.jabon),
        Producto("Popote Metálico", "Reutilizable, ideal para reducir el plástico.", R.drawable.popote)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFCDECCF))
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Productos ecológicos", fontSize = 28.sp, color = Color(0xFF1B5E20))
        Spacer(Modifier.height(16.dp))

        productos.forEach {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Image(
                        painter = painterResource(id = it.imagen),
                        contentDescription = it.nombre,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        contentScale = ContentScale.Crop
                    )
                    Text(it.nombre, fontSize = 20.sp, color = Color(0xFF1B5E20))
                    Text(it.descripcion)
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onVolver, modifier = Modifier.fillMaxWidth()) {
            Text("Volver")
        }
    }
}

@Composable
fun PantallaPlantas(onVolver: () -> Unit) {
    val plantas = listOf(
        Planta("Aloe Vera", "México", "Usada para curar quemaduras y cuidar la piel.", R.drawable.aloe),
        Planta("Lavanda", "Europa", "Conocida por su aroma relajante.", R.drawable.lavanda),
        Planta("Menta", "Asia", "Ayuda a la digestión y refresca el aliento.", R.drawable.menta),
        Planta("Eucalipto", "Sudeste de asia", "Sirve para problemas respiratorios y descongestión.", R.drawable.eucalipto)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFCDECCF))
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Plantas medicinales", fontSize = 28.sp, color = Color(0xFF1B5E20))
        Spacer(Modifier.height(16.dp))

        plantas.forEach {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Image(
                        painter = painterResource(id = it.imagen),
                        contentDescription = it.nombre,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        contentScale = ContentScale.Crop
                    )
                    Text(it.nombre, fontSize = 20.sp, color = Color(0xFF1B5E20))
                    Text("Origen: ${it.origen}")
                    Text("Uso: ${it.uso}")
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onVolver, modifier = Modifier.fillMaxWidth()) {
            Text("Volver")
        }
    }
}

data class Producto(val nombre: String, val descripcion: String, val imagen: Int)
data class Planta(val nombre: String, val origen: String, val uso: String, val imagen: Int)
